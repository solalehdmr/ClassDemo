// Updated: Feb 2020

// targeting all tab name variations when multiple tabs used per page
// targets id's starting with "tabs" - use sequential numbering "tab1", "tab2", etc
// documentation: http://api.jqueryui.com/tabs/
$(function() {

  var $tabs = $("[id^='tabs']").tabs();

  $("[id^='tab-']").each(function(i){

    var totalSize = $("[id^='tab-']").size() - 1;

    if (i != totalSize) {
        next = i + 2;
        $(this).append("<button class='next-tab tabbtn' rel='" + next + "'>Next Tab &#187;</button>");
    }

    if (i != 0) {
        prev = i;
        $(this).append("<button class='prev-tab tabbtn' rel='" + prev + "'>&#171; Prev Tab</button>");
    }
  
  });

  $(".next-tab").click(function () {
    $( "[id^='tabs']" ).tabs( "option", "active", $("[id^='tabs']").tabs('option', 'active')+1 );
  });
  $(".prev-tab").click(function () {
    $( "[id^='tabs']" ).tabs( "option", "active", $("[id^='tabs']").tabs('option', 'active')-1 );
  });

});



// tooltip anytime a title attribute is used in the document
// titles can be added to any object either manually written/coded or 
// via the insert quicklinks dropdown menu > insert attribute menu 
// documentation: http://api.jqueryui.com/tooltip/
$( document ).tooltip();

        $("#tooltip button").focus( function(){ 
          var btnname = $(this).text();

          $(this).attr("role", "tooltip").attr("aria-label", btnname);
        });



// Accordion 
// documentation: http://api.jqueryui.com/accordion/
$( function() {

  // custom icons plus and minus sign
  var icons = {
    header: "ui-icon-plus",
    activeHeader: "ui-icon-minus"
  };

  // targets id's starting with "accordion" - use sequential numbering "accordion1", "accordion2", etc
  $("[id^='accordion']").accordion({

    // false = panels are not open by default
    active: false,

    // true =  users can click to close opened panels
    collapsible: true,

    // the height of the panel will be based on the content
    heightStyle: "content",

    // sets the icon change to the variable above
    icons: icons,

    
    // Source: https://stackoverflow.com/a/15713502/8671887
    beforeActivate: function(event, ui) {
      // The accordion believes a panel is being opened
      if (ui.newHeader[0]) {
        var currHeader  = ui.newHeader;
        var currContent = currHeader.next(".ui-accordion-content");
      // The accordion believes a panel is being closed
      } else {
        var currHeader  = ui.oldHeader;
        var currContent = currHeader.next(".ui-accordion-content");
      }
      // Since we've changed the default behavior, this detects the actual status
      var isPanelSelected = currHeader.attr("aria-selected") == 'true';

      // Toggle the panel's header
      currHeader.toggleClass("ui-corner-all",isPanelSelected).toggleClass("accordion-header-active ui-state-active ui-corner-top",!isPanelSelected).attr("aria-selected",((!isPanelSelected).toString()));

      // Toggle the panel's icon
      currHeader.children(".ui-icon").toggleClass("ui-icon-plus",isPanelSelected).toggleClass("ui-icon-minus",!isPanelSelected);

      // Toggle the panel's content
      currContent.toggleClass("accordion-content-active",!isPanelSelected)    
      if (isPanelSelected) { currContent.slideUp(); }  else { currContent.slideDown(); }

      return false; // Cancels the default action
    }

  });

    var num = 0;

    // adds open all and close all button before the accordion
    $( "[id^='accordion']" ).before( "<p><button class='open' id='num" + num++ + "'>Open All</button> <button class='close'>Close All</button></p>" );

    // adds the UI hover styles to the open/close buttons
    $(".open, .close").mouseover(function () {
      $(this).addClass("ui-state-hover");
    })

    $(".open, .close").mouseleave(function () {
      $(this).removeClass("ui-state-hover");
    })


    //Source: https://stackoverflow.com/a/15839105
    // open and close button - expands and collapses the panels
    // edited to only target accordion elements
    $(".open").click(function () {
      $("[id^='accordion'] > .ui-accordion-header").removeClass("ui-corner-all").addClass("ui-accordion-header-active ui-state-active ui-corner-top").attr({
        "aria-selected": "true",
        "tabindex": "0"
      });
      $("[id^='accordion'] > .ui-accordion-header-icon").removeClass(icons.header).addClass(icons.activeHeader);
      $("[id^='accordion'] > .ui-accordion-header-icon").removeClass(icons.header).addClass(icons.activeHeader);
      $("[id^='accordion'] > .ui-accordion-content").addClass("ui-accordion-content-active").attr({
        "aria-expanded": "true",
        "aria-hidden": "false"
      }).show();
      $(this).attr("disabled","disabled").removeClass("ui-state-hover");
      $(".close").removeAttr("disabled");
    });

    $(".close").click(function () {
      $("[id^='accordion'] > .ui-accordion-header").removeClass("ui-accordion-header-active ui-state-active ui-corner-top").addClass("ui-corner-all").attr({
        "aria-selected": "false",
        "tabindex": "-1"
      });

      $("[id^='accordion'] > .ui-accordion-header-icon").removeClass(icons.activeHeader).addClass(icons.header);
      $("[id^='accordion'] > .ui-accordion-content").removeClass("ui-accordion-content-active").attr({
        "aria-expanded": "false",
        "aria-hidden": "true"
      }).hide();
      $(this).attr("disabled","disabled").removeClass("ui-state-hover");
      $(".open").removeAttr("disabled");
    });

    $("[id^='accordion'] > .ui-accordion-header").click(function () {
      $(".open").removeAttr("disabled");
      $(".close").removeAttr("disabled");
    });

});



// Caption Hide and reveal function
// should not have the open close button above the widget OR be affected by the open/close button for accordions
$( function() {
    $("[id^='caption']").accordion({
      // false = panels are not open by default
      active: false,

      // true =  users can click to close opened panels
      collapsible: true,
      
      // the height of the panel will be based on the content 
      heightStyle: "content"
    });
  } );



// author?
// responsive video, width adjuster
$(function() {

    var $allVideos = $("iframe[src^='//player.vimeo.com'], iframe[src^='//www.youtube.com'], object, embed"),
    $fluidEl = $("figure");

  $allVideos.each(function() {

    $(this)
      // jQuery .data does not work on object/embed elements
      .attr('data-aspectRatio', this.height / this.width)
      .removeAttr('height')
      .removeAttr('width');

  });

  $(window).resize(function() {

    var newWidth = $fluidEl.width();
    $allVideos.each(function() {

      var $el = $(this);
      $el
          .width(newWidth)
          .height(newWidth * $el.attr('data-aspectRatio'));

    });

  }).resize();

});






